<!DOCTYPE html>
<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default"
    data-assets-path="../assets/" data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title> @yield('page_title') </title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ url('admin/assets/img/favicon/favicon.ico') }}" />


    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet" />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="{{ url('admin/assets/vendor/fonts/boxicons.css') }}" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="{{ url('admin/assets/vendor/css/core.css') }}" class="template-customizer-core-css" />
    <link rel="stylesheet" href="{{ url('admin/assets/vendor/css/theme-default.css') }}"
        class="template-customizer-theme-css" />
    <link rel="stylesheet" href="{{ url('admin/assets/css/demo.css') }}" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="{{ url('admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css') }}" />

    <link rel="stylesheet" href="{{ url('admin/assets/vendor/libs/apex-charts/apex-charts.css') }}" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="{{ url('admin/assets/vendor/js/helpers.js') }}"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="{{ url('admin/assets/js/config.js') }}"></script>

    <!-- For Font awsome icons view.. -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- -->

    <!-- for ck editor -->
    <script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js" ></script>

    <!--  -->

</head>

<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <div class="app-brand demo">
                    <a href="{{ url('admin/dashboard') }}" class="app-brand-link">

                        <img class="normal-logo" src="{{ url('frontend/assets/images/logo_gst.gif') }}" alt="logo"
                            style="he
                        50px; width:100px;">
                        <span class="app-brand-text demo menu-text fw-bolder ms-2"> GST </span>
                    </a>

                    <a href="javascript:void(0);"
                        class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                        <i class="bx bx-chevron-left bx-sm align-middle"></i>
                    </a>
                </div>

                <div class="menu-inner-shadow"></div>

                <ul class="menu-inner py-1">
                    <!-- Dashboard -->
                    <li class="menu-item {{ Request::is('admin/dashboard') ? 'active' : '' }}">
                        <a href="{{ url('admin/dashboard') }}" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-home-circle"></i>
                            <div data-i18n="Analytics">Dashboard</div>
                        </a>
                    </li>

                    <!-- Layouts -->
                    <li
                        class="menu-item {{ Request::is('admin/homebanner') ? 'active open' : '' }} || {{ Request::is('admin/homeabout') ? 'active open' : '' }} || {{ Request::is('admin/homeabout') ? 'active open' : '' }}{{ Request::is('admin/homewhy') ? 'active open' : '' }} || {{ Request::is('admin/articles') ? 'active open' : '' }} || {{ Request::is('admin/addarticle') ? 'active open' : '' }}  || {{ Request::is('admin/faq') ? 'active open' : '' }} || {{ Request::is('admin/addfaq') ? 'active open' : '' }} || {{ Request::is('admin/editfaq') ? 'active open' : '' }} || {{ Request::is('admin/contact') ? 'active open' : '' }}">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-layout"></i>
                            <div data-i18n="website_managment">Website Management</div>
                        </a>

                        <ul class="menu-sub">
                            {{-- <li class="menu-item {{ Request::is('admin/homebanner') ? 'active' : '' }}">
                                <a href="{{ url('admin/homebanner') }}" class="menu-link">
                                    <div data-i18n="homebanner menu website_managment">Home Banner</div>
                                </a>
                            </li> --}}
                            <li class="menu-item {{ Request::is('admin/homeabout') ? 'active' : '' }}">
                                <a href="{{ url('admin/homeabout') }}" class="menu-link">
                                    <div data-i18n=" website_managment homeabout navbar">Home About </div>
                                </a>
                            </li>

                             <li class="menu-item {{ Request::is('admin/homewhy') ? 'active' : '' }}">
                                <a href="{{ url('admin/homewhy') }}" class="menu-link">
                                    <div data-i18n="Container">Home Why us?</div>
                                </a>
                            </li>

                            <li class="menu-item {{ Request::is('admin/articles') ? 'active' : '' }} || {{ Request::is('admin/addarticle') ? 'active' : '' }}">
                                <a href="{{ url('admin/articles') }}" class="menu-link">
                                    <div data-i18n="Fluid">Articles</div>
                                </a>
                            </li>
                            <li class="menu-item {{ Request::is('admin/faq') ? 'active' : '' }} || {{ Request::is('admin/addfaq') ? 'active' : '' }}">
                                <a href="{{ url('admin/faq') }}" class="menu-link">
                                    <div data-i18n="Fluid">FAQ</div>
                                </a>
                            </li>
                            <li class="menu-item {{ Request::is('admin/contact') ? 'active' : '' }}">
                                <a href="{{ url('admin/contact') }}" class="menu-link">
                                    <div data-i18n="homebanner menu website_managment">Contact</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    {{-- <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Category</span>
            </li> --}}
                    <li
                        class="menu-item {{ Request::is('admin/allcategory') ? 'active open' : '' }} || {{ Request::is('admin/addnewcategory') ? 'active open' : '' }} || {{ Request::is('admin/allsubcategory') ? 'active open' : '' }} || {{ Request::is('admin/addnewsubcategory') ? 'active open' : '' }}">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-dock-top"></i>
                            <div data-i18n="Category_Managment ">Category Management</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item {{ Request::is('admin/allcategory') ? 'active' : '' }}">
                                <a href="{{ url('admin/allcategory') }}" class="menu-link">
                                    <div data-i18n="Category_Managment">All Categories</div>
                                </a>
                            </li>
                            <li class="menu-item {{ Request::is('admin/addnewcategory') ? 'active' : '' }}">
                                <a href="{{ url('admin/addnewcategory') }}" class="menu-link">
                                    <div data-i18n="Category_Managment">Add New Category</div>
                                </a>
                            </li>
                            <li class="menu-item {{ Request::is('admin/allsubcategory') ? 'active' : '' }}">
                                <a href="{{ url('admin/allsubcategory') }}" class="menu-link">
                                    <div data-i18n="Category_Managment">All Sub-Category</div>
                                </a>
                            </li>
                            <li class="menu-item {{ Request::is('admin/addnewsubcategory') ? 'active' : '' }}">
                                <a href="{{ url('admin/addnewsubcategory') }}" class="menu-link">
                                    <div data-i18n="Category_Managment">Add New Sub-Category</div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item {{Request::is('admin/allservices') ? 'active open' : '' }} {{Request::is('admin/addnewservice') ? 'active open' : '' }} ">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-lock-open-alt"></i>
                            <div data-i18n="Authentications">Services Management</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item {{Request::is('admin/allservices') ? 'active' : '' }}">
                                <a href="{{ url('admin/allservices') }}" class="menu-link">
                                    <div data-i18n="Basic">All Services</div>
                                </a>
                            </li>
                            <li class="menu-item {{Request::is('admin/addnewservice') ? 'active' : '' }}">
                                <a href="{{ url('admin/addnewservice') }}" class="menu-link">
                                    <div data-i18n="Basic">Add New Service</div>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="menu-item {{Request::is('admin/allusers') ? 'active open' : '' }} || {{Request::is('admin/addnewuser') ? 'active open' : '' }}">
                        <a href="javascript:void(0);" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-cube-alt"></i>
                            <div data-i18n="Misc">User Management</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item {{Request::is('admin/allusers') ? 'active' : '' }}">
                                <a href="{{ url('admin/allusers') }}" class="menu-link">
                                    <div data-i18n="Error">All Users</div>
                                </a>
                            </li>
                            <li class="menu-item {{Request::is('admin/addnewuser') ? 'active' : '' }}">
                                <a href="{{ url('admin/addnewuser') }}" class="menu-link">
                                    <div data-i18n="Under Maintenance">Add New User</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!-- User interface -->
                    <li class="menu-item {{Request::is('admin/usertickets') ? 'active open' : '' }} || {{Request::is('admin/managertickets') ? 'active open' : '' }}">
                        <a href="javascript:void(0)" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-box"></i>
                            <div data-i18n="User interface">Tickets Management</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item {{Request::is('admin/usertickets') ? 'active' : '' }}">
                                <a href="{{ url('admin/usertickets') }}" class="menu-link">
                                    <div data-i18n="Accordion">User Tickets</div>
                                </a>
                            </li>
                            <li class="menu-item {{Request::is('admin/managertickets') ? 'active' : '' }}">
                                <a href="{{ url('admin/managertickets') }}" class="menu-link">
                                    <div data-i18n="Alerts">Manager Tickets</div>
                                </a>
                            </li>

                        </ul>
                    </li>

                    <li class="menu-item {{Request::is('admin/allorders') ? 'active open' : '' }} ">
                        <a href="javascript:void(0)" class="menu-link menu-toggle">
                            <i class="menu-icon tf-icons bx bx-box"></i>
                            <div data-i18n="User interface">Orders Management</div>
                        </a>
                        <ul class="menu-sub">
                            <li class="menu-item {{Request::is('admin/allorders') ? 'active' : '' }}">
                                <a href="{{ url('admin/allorders') }}" class="menu-link">
                                    <div data-i18n="Accordion">All Orders</div>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <!-- Forms & Tables -->
                    <li class="menu-header small text-uppercase"><span class="menu-header-text"> General </span>
                    </li>

                    <!-- Tables -->
                    <?php
                        $role = Session::get('ROLE');

                        if ($role === 'admin')
                        {
                            $profile = 'adminpage';
                            ?>
                                <style> .manager{ display: none}  </style>
                            <?php
                        }else
                        {
                            $profile = 'managerpage';
                            ?>
                            <style> .admin{ display: none} .btn-danger{ display: none} .clear-due-btn-manageuser{ display: none} </style>
                            <?php
                        }
                        ?>

                        <?php
                    ?>

                    <li class="admin menu-item {{ Request::is('admin/adminpage') ? 'active' : '' }}">
                        <a href="{{ url('admin/adminpage') }}" class="menu-link ">
                            <i class="menu-icon tf-icons bx bx-detail"></i>
                            <div data-i18n="Tables">Admin</div>
                        </a>
                    </li>

                    <li class="manager menu-item {{ Request::is('admin/managerpage') ? 'active' : '' }}">
                        <a href="{{ url('admin/managerpage') }}" class="menu-link">
                            <i class="menu-icon tf-icons bx bx-table"></i>
                            <div data-i18n="Tables">Manager</div>
                        </a>
                    </li>

                </ul>
            </aside>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->

                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
                    id="layout-navbar">
                    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                            <i class="bx bx-menu bx-sm"></i>
                        </a>
                    </div>

                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Search -->
                        {{-- <div class="navbar-nav align-items-center">
                            <div class="nav-item d-flex align-items-center">
                                <i class="bx bx-search fs-4 lh-0"></i>
                                <input type="text" class="form-control border-0 shadow-none"
                                    placeholder="Search..." aria-label="Search..." />
                            </div>
                        </div> --}}
                        <!-- /Search -->

                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- Place this tag where you want the button to render. -->

                            <!-- User -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);"
                                    data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <img src="{{ url('admin/assets/img/avatars/1.png') }}" alt
                                            class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="/admin/adminpage">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <img src="{{ url('admin/assets/img/avatars/1.png') }}" alt
                                                            class="w-px-40 h-auto rounded-circle" />
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-semibold d-block"> {{Session::get('ADMIN_USERNAME')}} </span>
                                                    <small class="text-muted">{{Session::get('ADMIN_EMAIL')}}</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        {{-- <a class="dropdown-item" href="/admin/adminpage"> --}}
                                            <a class="dropdown-item" href="/admin/{{$profile}}">
                                            <i class="bx bx-user me-2"></i>
                                            <span class="align-middle">My Profile</span>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="logout">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <!--/ User -->
                        </ul>
                    </div>
                </nav>

                <!-- / Navbar -->
