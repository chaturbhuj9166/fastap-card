@extends('admin.layouts.main')
@section('page_title', 'Admin ')
@section('main-container')


    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">General/</span> Admin </h4>

            @if ($message = Session::get('success'))
                <div class="alert alert-success alert-block">
                    <strong> {{ $message }} </strong>
                </div>
            @endif

            <!-- Basic Layout & Basic with Icons -->
            <div class="row">
                <!-- Basic Layout -->
                <div class="col-xxl">
                    <div class="card mb-4">
                        <div class="card-header d-flex align-items-center justify-content-between">
                            <h5 class="mb-0">Admin </h5>
                            <small class="text-muted float-end">Form</small>
                        </div>
                        <div class="card-body">

                            <form method="POST" action="/admin/adminpage/{{ $admin->id }}/update">
                                @csrf
                                @method('PUT')

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="username">User Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="username" name="username"
                                            placeholder="Enter Username" value="{{ old('username', $admin->username) }}" />

                                        @if ($errors->has('username'))
                                            <span class="text-danger"> {{ $errors->first('username') }} </span>
                                        @endif

                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="password">Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" id="password" name="password"
                                            placeholder="Enter Password" value="{{ old('password', $admin->password) }}" />

                                        @if ($errors->has('password'))
                                            <span class="text-danger"> {{ $errors->first('password') }} </span>
                                        @endif

                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="phone">Phone No</label>
                                    <div class="col-sm-10">
                                        <input type="text" id="phone" name="phone" class="form-control phone-mask"
                                            placeholder="Enter Phone No" value="{{ old('phone', $admin->phone) }}" />

                                        @if ($errors->has('phone'))
                                            <span class="text-danger"> {{ $errors->first('phone') }} </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="email">E-mail</label>
                                    <div class="col-sm-10">
                                        <div class="input-group input-group-merge">
                                            <input type="text" id="email" name="email" class="form-control"
                                                placeholder="Enter Email" value="{{ old('email', $admin->email) }}" />
                                            <span class="input-group-text" id="email">@example.com</span>
                                        </div>
                                        @if ($errors->has('email'))
                                        <span class="text-danger"> {{ $errors->first('email') }} </span>
                                    @endif

                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="address">Address</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="address" name="address"
                                            placeholder="Enter Address" value="{{ old('address', $admin->address) }}" />

                                        @if ($errors->has('address'))
                                            <span class="text-danger"> {{ $errors->first('address') }} </span>
                                        @endif

                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-sm-2 col-form-label" for="message">Message</label>
                                    <div class="col-sm-10">
                                        <textarea rows="6" cols="50" id="message" name="message" class="form-control"
                                            placeholder="Hi, Do you have a moment to talk Joe?" aria-label="Hi, Do you have a moment to talk Joe?"
                                            aria-describedby="basic-icon-default-message2">{{ old('message', $admin->message) }}</textarea>
                                        @if ($errors->has('message'))
                                            <span class="text-danger"> {{ $errors->first('message') }} </span>
                                        @endif
                                    </div>
                                </div>
                                <div class="row justify-content-end">
                                    <div class="col-sm-10">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- / Content -->


    @endsection
